package pkg1;

import org.openqa.selenium.chrome.ChromeDriver;

public class C {

	/*public static void main(String[] args) {
	   System.setProperty("webdriver.chrome.drive", "chromedriver.exe");
	   ChromeDriver driver= new ChromeDriver();
	   driver.get("https://jamba.fishbowlcloud.com/#/insights/cockpit/");

	}*/

}
